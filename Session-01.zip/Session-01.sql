-- create database 
create database demo_db

-- use / swtich database 
use demo_db

--create new table for product , and customer, sales_order 

--identity(1,1) : auto generate column 
create table customer
(
cid int identity(1,1) primary key,
fname varchar(30) not null,
lname varchar(30) null,
email varchar(100) unique,
gender char(1) check (gender in ('M','F')),
creat_date   datetime default getdate()
)


create table product
(
pid int identity(1,1) primary key,
pname varchar(30) not null,
pprice int not null,
sprice int not null,
)

create table sales_order
(
oid int identity(1,1) primary key,
cid  int foreign key references customer(cid),
pid int foreign key references product(pid),
qty int not null,
odate datetime default getdate()
)

-- insert data in tables
insert into customer(fname,email)
values('Jatin','jatin@gmail.com'),
('Monika','monika@gmail.com'),
('Nitisha','nitisha@gmail.com'),
('Raman','ramanb@gmail.com')

select * from customer

update customer
set gender ='F'
where cid not in (1,2,5)




insert into product(pname,pprice,sprice)
values('Iphone',70000,80000),
('Mac-laptop',170000,180000),
('Dell-laptop',30000,40000),
('Hp-laptop',40000,50000)


insert into sales_order(cid,pid,qty)
values(4,3,5)

select * from customer 
select * from product 
select * from sales_order
 
--- show the list customer who has not bought any product till now
--1. solution 
select * from customer where cid not in (select cid from sales_order)

--2. solution 
select c.* 
from customer as c left join sales_order as s
		on c.cid = s.cid
		where s.cid is null
